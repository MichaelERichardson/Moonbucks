﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainForm))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DiscountCheckBox = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.zipTextBox = New System.Windows.Forms.TextBox()
        Me.stateTextBox = New System.Windows.Forms.TextBox()
        Me.cityTextBox = New System.Windows.Forms.TextBox()
        Me.addressTextBox = New System.Windows.Forms.TextBox()
        Me.nameTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.totalLabel = New System.Windows.Forms.Label()
        Me.totalpriceLabel = New System.Windows.Forms.Label()
        Me.taxLabel = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.priceLabel = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.poundsTextBox = New System.Windows.Forms.TextBox()
        Me.printButton = New System.Windows.Forms.Button()
        Me.clearButton = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.calButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.IrishRadioButton = New System.Windows.Forms.RadioButton()
        Me.EarlRadioButton = New System.Windows.Forms.RadioButton()
        Me.CaramelRadioButton = New System.Windows.Forms.RadioButton()
        Me.HouseRadioButton = New System.Windows.Forms.RadioButton()
        Me.darkRadioButton = New System.Windows.Forms.RadioButton()
        Me.mediumRadioButton = New System.Windows.Forms.RadioButton()
        Me.PrintForm1 = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.DecafCheckBox = New System.Windows.Forms.CheckBox()
        Me.billNumLabel = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.viewButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(174, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Order Form"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.xid_14110092_1
        Me.PictureBox1.Location = New System.Drawing.Point(360, 47)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(167, 153)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GroupBox1.Controls.Add(Me.DiscountCheckBox)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.zipTextBox)
        Me.GroupBox1.Controls.Add(Me.stateTextBox)
        Me.GroupBox1.Controls.Add(Me.cityTextBox)
        Me.GroupBox1.Controls.Add(Me.addressTextBox)
        Me.GroupBox1.Controls.Add(Me.nameTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(43, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(271, 233)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Information:"
        '
        'DiscountCheckBox
        '
        Me.DiscountCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DiscountCheckBox.AutoSize = True
        Me.DiscountCheckBox.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DiscountCheckBox.Location = New System.Drawing.Point(12, 205)
        Me.DiscountCheckBox.Name = "DiscountCheckBox"
        Me.DiscountCheckBox.Size = New System.Drawing.Size(140, 20)
        Me.DiscountCheckBox.TabIndex = 5
        Me.DiscountCheckBox.Text = "Employee Discount"
        Me.DiscountCheckBox.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 176)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 18)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Zip:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 143)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(49, 18)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "State:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 107)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 18)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "City:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 74)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 18)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Address:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 41)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 18)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Name:"
        '
        'zipTextBox
        '
        Me.zipTextBox.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zipTextBox.Location = New System.Drawing.Point(94, 173)
        Me.zipTextBox.Name = "zipTextBox"
        Me.zipTextBox.Size = New System.Drawing.Size(82, 26)
        Me.zipTextBox.TabIndex = 4
        Me.zipTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'stateTextBox
        '
        Me.stateTextBox.Location = New System.Drawing.Point(94, 140)
        Me.stateTextBox.Name = "stateTextBox"
        Me.stateTextBox.Size = New System.Drawing.Size(82, 26)
        Me.stateTextBox.TabIndex = 3
        '
        'cityTextBox
        '
        Me.cityTextBox.Location = New System.Drawing.Point(94, 104)
        Me.cityTextBox.Name = "cityTextBox"
        Me.cityTextBox.Size = New System.Drawing.Size(163, 26)
        Me.cityTextBox.TabIndex = 2
        '
        'addressTextBox
        '
        Me.addressTextBox.Location = New System.Drawing.Point(94, 71)
        Me.addressTextBox.Name = "addressTextBox"
        Me.addressTextBox.Size = New System.Drawing.Size(163, 26)
        Me.addressTextBox.TabIndex = 1
        '
        'nameTextBox
        '
        Me.nameTextBox.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nameTextBox.Location = New System.Drawing.Point(94, 38)
        Me.nameTextBox.Name = "nameTextBox"
        Me.nameTextBox.Size = New System.Drawing.Size(163, 26)
        Me.nameTextBox.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.totalLabel)
        Me.GroupBox2.Controls.Add(Me.totalpriceLabel)
        Me.GroupBox2.Controls.Add(Me.taxLabel)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.priceLabel)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(309, 296)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(218, 209)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Billing:"
        '
        'totalLabel
        '
        Me.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.totalLabel.Location = New System.Drawing.Point(106, 33)
        Me.totalLabel.Name = "totalLabel"
        Me.totalLabel.Size = New System.Drawing.Size(94, 27)
        Me.totalLabel.TabIndex = 9
        Me.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'totalpriceLabel
        '
        Me.totalpriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.totalpriceLabel.Location = New System.Drawing.Point(106, 167)
        Me.totalpriceLabel.Name = "totalpriceLabel"
        Me.totalpriceLabel.Size = New System.Drawing.Size(94, 27)
        Me.totalpriceLabel.TabIndex = 10
        Me.totalpriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'taxLabel
        '
        Me.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.taxLabel.Location = New System.Drawing.Point(106, 123)
        Me.taxLabel.Name = "taxLabel"
        Me.taxLabel.Size = New System.Drawing.Size(94, 27)
        Me.taxLabel.TabIndex = 9
        Me.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 37)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 18)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Total:"
        '
        'priceLabel
        '
        Me.priceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.priceLabel.Location = New System.Drawing.Point(106, 72)
        Me.priceLabel.Name = "priceLabel"
        Me.priceLabel.Size = New System.Drawing.Size(94, 27)
        Me.priceLabel.TabIndex = 8
        Me.priceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 171)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(85, 18)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Total price:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(15, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 18)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Tax:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Price:"
        '
        'poundsTextBox
        '
        Me.poundsTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.poundsTextBox.Location = New System.Drawing.Point(213, 335)
        Me.poundsTextBox.Name = "poundsTextBox"
        Me.poundsTextBox.Size = New System.Drawing.Size(73, 26)
        Me.poundsTextBox.TabIndex = 3
        Me.poundsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'printButton
        '
        Me.printButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.printButton.Location = New System.Drawing.Point(227, 536)
        Me.printButton.Name = "printButton"
        Me.printButton.Size = New System.Drawing.Size(98, 30)
        Me.printButton.TabIndex = 8
        Me.printButton.Text = "&Print"
        Me.printButton.UseVisualStyleBackColor = True
        '
        'clearButton
        '
        Me.clearButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.clearButton.Location = New System.Drawing.Point(331, 536)
        Me.clearButton.Name = "clearButton"
        Me.clearButton.Size = New System.Drawing.Size(98, 30)
        Me.clearButton.TabIndex = 9
        Me.clearButton.Text = "C&lear"
        Me.clearButton.UseVisualStyleBackColor = True
        '
        'exitButton
        '
        Me.exitButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.exitButton.BackColor = System.Drawing.Color.Transparent
        Me.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.exitButton.Location = New System.Drawing.Point(434, 536)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(98, 30)
        Me.exitButton.TabIndex = 10
        Me.exitButton.Text = "E&xit"
        Me.exitButton.UseVisualStyleBackColor = False
        '
        'calButton
        '
        Me.calButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.calButton.Location = New System.Drawing.Point(123, 536)
        Me.calButton.Name = "calButton"
        Me.calButton.Size = New System.Drawing.Size(98, 30)
        Me.calButton.TabIndex = 7
        Me.calButton.Text = "&Calculate"
        Me.calButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(210, 296)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 36)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Number of" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Pounds:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GroupBox3.Controls.Add(Me.IrishRadioButton)
        Me.GroupBox3.Controls.Add(Me.EarlRadioButton)
        Me.GroupBox3.Controls.Add(Me.CaramelRadioButton)
        Me.GroupBox3.Controls.Add(Me.HouseRadioButton)
        Me.GroupBox3.Controls.Add(Me.darkRadioButton)
        Me.GroupBox3.Controls.Add(Me.mediumRadioButton)
        Me.GroupBox3.Location = New System.Drawing.Point(19, 296)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(185, 209)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Coffee and Tea Blends"
        '
        'IrishRadioButton
        '
        Me.IrishRadioButton.AutoSize = True
        Me.IrishRadioButton.Location = New System.Drawing.Point(6, 165)
        Me.IrishRadioButton.Name = "IrishRadioButton"
        Me.IrishRadioButton.Size = New System.Drawing.Size(114, 17)
        Me.IrishRadioButton.TabIndex = 5
        Me.IrishRadioButton.TabStop = True
        Me.IrishRadioButton.Text = "Irish Breakfast Tea"
        Me.IrishRadioButton.UseVisualStyleBackColor = True
        '
        'EarlRadioButton
        '
        Me.EarlRadioButton.AutoSize = True
        Me.EarlRadioButton.Location = New System.Drawing.Point(6, 137)
        Me.EarlRadioButton.Name = "EarlRadioButton"
        Me.EarlRadioButton.Size = New System.Drawing.Size(90, 17)
        Me.EarlRadioButton.TabIndex = 4
        Me.EarlRadioButton.TabStop = True
        Me.EarlRadioButton.Text = "Earl Grey Tea"
        Me.EarlRadioButton.UseVisualStyleBackColor = True
        '
        'CaramelRadioButton
        '
        Me.CaramelRadioButton.AutoSize = True
        Me.CaramelRadioButton.Location = New System.Drawing.Point(6, 109)
        Me.CaramelRadioButton.Name = "CaramelRadioButton"
        Me.CaramelRadioButton.Size = New System.Drawing.Size(94, 17)
        Me.CaramelRadioButton.TabIndex = 3
        Me.CaramelRadioButton.TabStop = True
        Me.CaramelRadioButton.Text = "Caramel Roast"
        Me.CaramelRadioButton.UseVisualStyleBackColor = True
        '
        'HouseRadioButton
        '
        Me.HouseRadioButton.AutoSize = True
        Me.HouseRadioButton.Location = New System.Drawing.Point(7, 81)
        Me.HouseRadioButton.Name = "HouseRadioButton"
        Me.HouseRadioButton.Size = New System.Drawing.Size(86, 17)
        Me.HouseRadioButton.TabIndex = 2
        Me.HouseRadioButton.TabStop = True
        Me.HouseRadioButton.Text = "House Blend"
        Me.HouseRadioButton.UseVisualStyleBackColor = True
        '
        'darkRadioButton
        '
        Me.darkRadioButton.AutoSize = True
        Me.darkRadioButton.Location = New System.Drawing.Point(6, 53)
        Me.darkRadioButton.Name = "darkRadioButton"
        Me.darkRadioButton.Size = New System.Drawing.Size(79, 17)
        Me.darkRadioButton.TabIndex = 1
        Me.darkRadioButton.TabStop = True
        Me.darkRadioButton.Text = "Dark Roast"
        Me.darkRadioButton.UseVisualStyleBackColor = True
        '
        'mediumRadioButton
        '
        Me.mediumRadioButton.AutoSize = True
        Me.mediumRadioButton.Location = New System.Drawing.Point(7, 26)
        Me.mediumRadioButton.Name = "mediumRadioButton"
        Me.mediumRadioButton.Size = New System.Drawing.Size(93, 17)
        Me.mediumRadioButton.TabIndex = 0
        Me.mediumRadioButton.TabStop = True
        Me.mediumRadioButton.Text = "Medium Roast"
        Me.mediumRadioButton.UseVisualStyleBackColor = True
        '
        'PrintForm1
        '
        Me.PrintForm1.DocumentName = "document"
        Me.PrintForm1.Form = Me
        Me.PrintForm1.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm1.PrinterSettings = CType(resources.GetObject("PrintForm1.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm1.PrintFileName = Nothing
        '
        'DecafCheckBox
        '
        Me.DecafCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DecafCheckBox.AutoSize = True
        Me.DecafCheckBox.Location = New System.Drawing.Point(214, 400)
        Me.DecafCheckBox.Name = "DecafCheckBox"
        Me.DecafCheckBox.Size = New System.Drawing.Size(69, 22)
        Me.DecafCheckBox.TabIndex = 5
        Me.DecafCheckBox.Text = "Decaf"
        Me.DecafCheckBox.UseVisualStyleBackColor = True
        '
        'billNumLabel
        '
        Me.billNumLabel.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.billNumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.billNumLabel.Location = New System.Drawing.Point(433, 229)
        Me.billNumLabel.Name = "billNumLabel"
        Me.billNumLabel.Size = New System.Drawing.Size(76, 27)
        Me.billNumLabel.TabIndex = 11
        Me.billNumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(320, 233)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 18)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Billing Number:"
        '
        'viewButton
        '
        Me.viewButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.viewButton.Location = New System.Drawing.Point(19, 536)
        Me.viewButton.Name = "viewButton"
        Me.viewButton.Size = New System.Drawing.Size(98, 30)
        Me.viewButton.TabIndex = 6
        Me.viewButton.Text = "&View"
        Me.viewButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "mediumRoast.jpg")
        Me.ImageList1.Images.SetKeyName(1, "darkRoast.jpg")
        Me.ImageList1.Images.SetKeyName(2, "houseBlend.jpg")
        Me.ImageList1.Images.SetKeyName(3, "CaramelRoast.jpg")
        Me.ImageList1.Images.SetKeyName(4, "earlGray.jpg")
        Me.ImageList1.Images.SetKeyName(5, "IrishBreakfast.jpg")
        '
        'mainForm
        '
        Me.AcceptButton = Me.calButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.exitButton
        Me.ClientSize = New System.Drawing.Size(554, 578)
        Me.Controls.Add(Me.viewButton)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.billNumLabel)
        Me.Controls.Add(Me.DecafCheckBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.poundsTextBox)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.calButton)
        Me.Controls.Add(Me.exitButton)
        Me.Controls.Add(Me.clearButton)
        Me.Controls.Add(Me.printButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "mainForm"
        Me.Text = "Moonbucks Coffee"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents zipTextBox As System.Windows.Forms.TextBox
    Friend WithEvents stateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents cityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents addressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents nameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents poundsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents printButton As System.Windows.Forms.Button
    Friend WithEvents clearButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents calButton As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents totalpriceLabel As System.Windows.Forms.Label
    Friend WithEvents taxLabel As System.Windows.Forms.Label
    Friend WithEvents priceLabel As System.Windows.Forms.Label
    Friend WithEvents totalLabel As System.Windows.Forms.Label
    Friend WithEvents PrintForm1 As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
    Friend WithEvents DiscountCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DecafCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents IrishRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents EarlRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CaramelRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents HouseRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents darkRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents mediumRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents billNumLabel As System.Windows.Forms.Label
    Friend WithEvents viewButton As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList

End Class
