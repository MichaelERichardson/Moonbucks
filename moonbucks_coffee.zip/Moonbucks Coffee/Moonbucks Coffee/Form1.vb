﻿' Project name:         Moonbucks Coffee Project
' Project purpose:      Calculates the pounds and total price of coffee ordered by the customer
'                       I made the background white to save Moonbucks cost on printer ink
'
' Created by:           Michael Richardson on 03/14/2013
' Modified by:          Michael Richardson on 03/20/2013
'                       added code to calculate the price of coffee ordered
' Modified by:          Michael Richardson on 03/23/2013
'                       added code to calculate discounts & add code to start input at 0
' Modified by:          Michael Richardson on 04/20/2013
'                       added radio buttons, new prices and the code to make them work
' Modified by:          Michael Richardson on 04/20/2013
'                       added a view botton and code to show the coffee images
' Modified by:          Michael Richardson on 04/20/2013
'                       added new private subs and functions to help calculate the order

Option Explicit On
Option Strict On
Option Infer Off

Public Class mainForm
    Private newOrder As Boolean
    Private Sub exitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitButton.Click
        Close()
    End Sub

    Private Sub calButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles calButton.Click
        Dim price As Single
        Dim randHold As Integer
        Dim randGen As New Random

        If newOrder = True Then
            randHold = randGen.Next(1000, 9999)
            billNumLabel.Text = CStr(randHold)
            PictureBox1.Image = My.Resources.xid_14110093_1
        End If


        price = calPrice()
        showOutput(price)


        newOrder = False

    End Sub
    Private Sub showOutput(ByVal priceOut As Single)
        Static totalCoffee As Integer
        Const Tax As Single = 0.085

        If newOrder = True Then
            totalCoffee = 0
        End If
        totalCoffee += CInt(poundsTextBox.Text)

        priceLabel.Text = priceOut.ToString("C2")
        taxLabel.Text = (priceOut * Tax).ToString("C2")
        totalpriceLabel.Text = (priceOut + (priceOut * Tax)).ToString("C2")
        totalLabel.Text = totalCoffee.ToString
    End Sub
    Private Function calPrice() As Single
        Const emDicount As Single = 0.1
        Const Dicount As Single = 0.02
        Static priceTotal, coffeePounds As Single
        Dim CoffeeHolder, coffPrice, priceHolder As Single

        If newOrder = True Then
            priceTotal = 0
            coffeePounds = 0
        End If

        Select Case True
            Case mediumRadioButton.Checked
                coffPrice = 11.15
            Case darkRadioButton.Checked
                coffPrice = 11.15
            Case HouseRadioButton.Checked
                coffPrice = 10.55
            Case CaramelRadioButton.Checked
                coffPrice = 12.15
            Case EarlRadioButton.Checked
                coffPrice = 8.95
            Case Else
                coffPrice = 7.95
        End Select

        CoffeeHolder = CSng(poundsTextBox.Text)
        coffeePounds += CoffeeHolder

        If DecafCheckBox.Checked = True Then
            coffPrice = (coffPrice - 1) * CoffeeHolder
        Else
            coffPrice = coffPrice * CoffeeHolder
        End If

        If DiscountCheckBox.Checked = True Then
            priceTotal += coffPrice - (coffPrice * emDicount)
            priceHolder = priceTotal
        Else
            If coffeePounds > 10 Then
                priceTotal += coffPrice
                priceHolder = priceTotal - (priceTotal * Dicount)
            Else
                priceTotal += coffPrice
                priceHolder = priceTotal
            End If
        End If
        Return priceHolder
    End Function
    
    Private Sub clearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearButton.Click
        nameTextBox.ResetText()
        addressTextBox.ResetText()
        cityTextBox.ResetText()
        stateTextBox.ResetText()
        zipTextBox.ResetText()
        poundsTextBox.ResetText()
        totalLabel.ResetText()
        priceLabel.ResetText()
        taxLabel.ResetText()
        totalpriceLabel.ResetText()
        billNumLabel.ResetText()

        DiscountCheckBox.Checked = False
        mediumRadioButton.Checked = False
        darkRadioButton.Checked = False
        HouseRadioButton.Checked = False
        CaramelRadioButton.Checked = False
        EarlRadioButton.Checked = False
        IrishRadioButton.Checked = False
        DecafCheckBox.Checked = False

        nameTextBox.Focus()
        newOrder = True
        PictureBox1.Image = My.Resources.xid_14110092_1

    End Sub

    Private Sub printButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printButton.Click
        PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm1.Print()
    End Sub

    Private Sub mainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        newOrder = True
        nameTextBox.Focus()
    End Sub

    Private Sub viewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viewButton.Click
        Dim numImages As Integer = ImageList1.Images.Count

        For index As Integer = 0 To numImages - 1
            PictureBox1.Image = ImageList1.Images.Item(index)
            Me.Refresh()
            System.Threading.Thread.Sleep(1000)
        Next index
    End Sub

End Class
